#include "my_str.h"

void rm_space(char *s) {
    rm_left_space(s);
    rm_right_space(s);

}